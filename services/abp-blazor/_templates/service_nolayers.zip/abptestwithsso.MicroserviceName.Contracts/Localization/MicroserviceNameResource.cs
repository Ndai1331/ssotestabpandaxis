﻿using Volo.Abp.Localization;

namespace abptestwithsso.MicroserviceName.Localization;

[LocalizationResourceName("MicroserviceName")]
public class MicroserviceNameResource
{

}
