using abptestwithsso.MicroserviceName.Tests;
using Microsoft.AspNetCore.Builder;
using Volo.Abp.AspNetCore.TestBase;

var builder = WebApplication.CreateBuilder();
builder.Environment.ContentRootPath = GetWebProjectContentRootPathHelper.Get("abptestwithsso.MicroserviceName.csproj"); 
await builder.RunAbpModuleAsync<MicroserviceNameTestsModule>(applicationName: "abptestwithsso.MicroserviceName");

public partial class TestProgram
{
}
