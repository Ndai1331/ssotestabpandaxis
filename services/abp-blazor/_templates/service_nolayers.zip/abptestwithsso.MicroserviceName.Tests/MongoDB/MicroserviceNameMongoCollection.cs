﻿using Xunit;

namespace abptestwithsso.MicroserviceName.Tests.MongoDB;

[CollectionDefinition("MicroserviceName collection")]
public class MicroserviceNameMongoCollection: MicroserviceNameMongoDbCollectionFixtureBase
{

}