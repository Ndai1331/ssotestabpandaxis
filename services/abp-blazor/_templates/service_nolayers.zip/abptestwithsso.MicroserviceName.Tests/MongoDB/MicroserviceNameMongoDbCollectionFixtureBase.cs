﻿using Xunit;

namespace abptestwithsso.MicroserviceName.Tests.MongoDB;

public class MicroserviceNameMongoDbCollectionFixtureBase : ICollectionFixture<MicroserviceNameMongoDbFixture>
{

}