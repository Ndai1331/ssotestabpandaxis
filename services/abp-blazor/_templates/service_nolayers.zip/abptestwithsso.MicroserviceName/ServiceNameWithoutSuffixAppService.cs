﻿using abptestwithsso.MicroserviceName.Localization;
using Volo.Abp.Application.Services;

namespace abptestwithsso.MicroserviceName;

public abstract class ServiceNameWithoutSuffixAppService : ApplicationService
{
    protected ServiceNameWithoutSuffixAppService()
    {
        LocalizationResource = typeof(MicroserviceNameResource);
        ObjectMapperContext = typeof(abptestwithssoMicroserviceNameModule);
    }
}