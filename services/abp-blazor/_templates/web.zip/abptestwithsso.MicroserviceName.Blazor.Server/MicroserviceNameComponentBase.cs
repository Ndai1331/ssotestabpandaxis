﻿using abptestwithsso.MicroserviceName.Localization;
using Volo.Abp.AspNetCore.Components;

namespace abptestwithsso.MicroserviceName;

public abstract class MicroserviceNameComponentBase : AbpComponentBase
{
    protected MicroserviceNameComponentBase()
    {
        LocalizationResource = typeof(MicroserviceNameResource);
    }
}
