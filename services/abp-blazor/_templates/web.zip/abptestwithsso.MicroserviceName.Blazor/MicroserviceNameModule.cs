﻿{{~ if config.blazor_ui_library == "mudblazor" ~}}
using global::MudBlazor;
using Volo.Abp.MudBlazorUI;
{{~ else ~}}
using Blazorise;
using Blazorise.Bootstrap5;
using Blazorise.Icons.FontAwesome;
{{~ end ~}}
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using abptestwithsso.MicroserviceName.Navigation;
{{~ if config.blazor_ui_library == "mudblazor" ~}}
using Volo.Abp.AspNetCore.Components.Web.Theming.MudBlazor.Routing;
{{~ else ~}}
using Volo.Abp.AspNetCore.Components.Web.Theming.Routing;
{{~ end ~}}
{{~ if config.theme == "basic" ~}}
{{~ if config.blazor_ui_library == "mudblazor" ~}}
using Volo.Abp.AspNetCore.Components.Web.MudBlazorBasicTheme.Themes.Basic;
{{~ else ~}}
using Volo.Abp.AspNetCore.Components.Web.BasicTheme.Themes.Basic;
{{~ end ~}}
{{~ if config.blazor_ui_library == "mudblazor" ~}}
using Volo.Abp.AspNetCore.Components.WebAssembly.MudBlazorBasicTheme;
{{~ else ~}}
using Volo.Abp.AspNetCore.Components.WebAssembly.BasicTheme;
{{~ end ~}}
{{~ else if config.theme == "leptonx" ~}}
{{~ if config.blazor_ui_library == "mudblazor" ~}}
using Volo.Abp.AspNetCore.Components.Web.MudBlazorLeptonXTheme.Components;
{{~ else ~}}
using Volo.Abp.AspNetCore.Components.Web.LeptonXTheme.Components;
{{~ end ~}}
{{~ if config.blazor_ui_library == "mudblazor" ~}}
using Volo.Abp.AspNetCore.Components.WebAssembly.MudBlazorLeptonXTheme;
{{~ else ~}}
using Volo.Abp.AspNetCore.Components.WebAssembly.LeptonXTheme;
{{~ end ~}}
using Volo.Abp.LeptonX.Shared;
{{~ end ~}}
using Volo.Abp.Autofac.WebAssembly;
using Volo.Abp.Mapperly;
using abptestwithsso.MicroserviceName.Localization;
using Volo.Abp.Localization;
using Volo.Abp.VirtualFileSystem;
using Volo.Abp.Modularity;
using Volo.Abp.UI.Navigation;

namespace abptestwithsso.MicroserviceName;

[DependsOn(
    {{~ if config.theme == "basic" ~}}
    {{~ if config.blazor_ui_library == "mudblazor" ~}}
    typeof(AbpAspNetCoreComponentsWebAssemblyMudBlazorBasicThemeModule),
    {{~ else ~}}
    typeof(AbpAspNetCoreComponentsWebAssemblyBasicThemeModule),
    {{~ end ~}}
    {{~ else if config.theme == "leptonx" ~}}
    {{~ if config.blazor_ui_library == "mudblazor" ~}}
    typeof(AbpAspNetCoreComponentsWebAssemblyMudBlazorLeptonXThemeModule),
    {{~ else ~}}
    typeof(AbpAspNetCoreComponentsWebAssemblyLeptonXThemeModule),
    {{~ end ~}}
    {{~ end ~}}    
    typeof(AbpAutofacWebAssemblyModule)
)]
public class MicroserviceNameModule : AbpModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var environment = context.Services.GetSingletonInstance<IWebAssemblyHostEnvironment>();
        var builder = context.Services.GetSingletonInstance<WebAssemblyHostBuilder>();

        ConfigureAuthentication(builder);
        ConfigureHttpClient(context, environment);
        ConfigureBlazorise(context);
        ConfigureRouter(context);
        ConfigureUI(builder);
        ConfigureNavigation(context);
        ConfigureLocalization();
        {{~ if config.theme == "leptonx" ~}}
        ConfigureLeptonXTheme();
        {{~ end ~}}
    }

    private void ConfigureLocalization()
    {
        Configure<AbpVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MicroserviceNameResource>(typeof(MicroserviceNameModule).Namespace);
        });

        Configure<AbpLocalizationOptions>(options =>
        {
            options.Resources
                .Add<MicroserviceNameResource>("en")
                .AddVirtualJson("/Localization/MicroserviceName");

            options.DefaultResourceType = typeof(MicroserviceNameResource);
        });
    }
    {{~ if config.theme == "leptonx" ~}}
    
    private void ConfigureLeptonXTheme()
    {
        Configure<LeptonXThemeOptions>(options =>
        {
            {{~ if config.theme_style == "system" ~}}
            options.DefaultStyle = LeptonXStyleNames.System;
            {{~ else if config.theme_style == "dim" ~}}
            options.DefaultStyle = LeptonXStyleNames.Dim;
            {{~ else if config.theme_style == "light" ~}}
            options.DefaultStyle = LeptonXStyleNames.Light;
            {{~ else if config.theme_style == "dark" ~}}
            options.DefaultStyle = LeptonXStyleNames.Dark;
            {{~ end ~}}
        });
    }
    {{~ end ~}}

    private void ConfigureRouter(ServiceConfigurationContext context)
    {
        Configure<AbpRouterOptions>(options =>
        {
            options.AppAssembly = typeof(MicroserviceNameModule).Assembly;
        });
    }

    private void ConfigureNavigation(ServiceConfigurationContext context)
    {
        Configure<AbpNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MicroserviceNameMenuContributor(context.Services.GetConfiguration()));
        });
    }

    private void ConfigureBlazorise(ServiceConfigurationContext context)
    {
        {{~ if config.blazor_ui_library == "mudblazor" ~}}
        // MudBlazor services are registered by AbpMudBlazorUIModule.
        {{~ else ~}}
        context.Services
            .AddBlazorise(options =>
            {
                // TODO (IMPORTANT): To use Blazorise, you need a license key. Get your license key directly from Blazorise, follow  the instructions at https://abp.io/faq#how-to-get-blazorise-license-key
                //options.ProductToken = "Your Product Token";
            })
            .AddBootstrap5Providers()
            .AddFontAwesomeIcons();
            {{~ end ~}}
    }

    private static void ConfigureAuthentication(WebAssemblyHostBuilder builder)
    {
        builder.Services.AddOidcAuthentication(options =>
        {
            builder.Configuration.Bind("AuthServer", options.ProviderOptions);
            
        });
    }

    private static void ConfigureUI(WebAssemblyHostBuilder builder)
    {
        builder.RootComponents.Add<App>("#ApplicationContainer");
    }

    private static void ConfigureHttpClient(ServiceConfigurationContext context, IWebAssemblyHostEnvironment environment)
    {
        context.Services.AddTransient(sp => new HttpClient
        {
            BaseAddress = new Uri(environment.BaseAddress)
        });
    }
}
