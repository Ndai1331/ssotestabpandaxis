﻿namespace abptestwithsso.MicroserviceName.Pages;

public partial class Index
{

}
