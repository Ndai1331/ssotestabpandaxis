﻿using Volo.Abp.Ui.Branding;

namespace abptestwithsso.MicroserviceName;

public class MicroserviceNameBrandingProvider : DefaultBrandingProvider
{
    public override string AppName => "MicroserviceName";
}
